<?php

namespace App\Http\Requests\SellingUnit;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PurchaseUnitFormRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'purchase_unit_name' => [
                'required',
                'string',
                'max:50',
                Rule::unique('purchase_units')
                    ->where('parent_purchase_unit_id', $this->input('parent_purchase_unit_id'))
                    ->where('measurement_group_id', $this->input('measurement_group_id')) // Ensure uniqueness within the group and level
                    ->ignore($this->route('purchase_unit')), // Ignore current entry during update
            ],
            'measurement_group_id' => [
                'required',
                'uuid',
                function ($attribute, $value, $fail) {
                    // Check if parent_purchase_unit_id is NULL (this is a top-level unit)
                    if (is_null($this->input('parent_purchase_unit_id'))) {
                        // If it's a top-level unit, check if there's already an existing parent with NULL parent_purchase_unit_id
                        $existingParent = \DB::table('purchase_units')
                            ->whereNull('parent_purchase_unit_id') // parent_purchase_unit_id is NULL
                            ->where('measurement_group_id', $this->input('measurement_group_id'))
                            ->where('id', '!=', $this->route('purchase_unit')) // Ignore the current record during update
                            ->exists();

                        if ($existingParent) {
                            $fail('Only one top-level parent unit is allowed for each measurement group.');
                        }
                    }
                }
            ],

            // Custom validation for parent_purchase_unit_id (ensure only one NULL parent per group)
            'parent_purchase_unit_id' => [
                'nullable',
                'uuid',
                'exists:purchase_units,id', // Ensure the provided parent ID exists in the purchase_units table
                function ($attribute, $value, $fail) {
                    // Check if the parent_purchase_unit_id is null, which signifies the first-level parent
                    if (!is_null($value)) {
                        $parentUnits = \DB::table('purchase_units')
                            ->where('parent_purchase_unit_id', $value)
                            ->where('measurement_group_id', $this->input('measurement_group_id'))
                            ->count();

                        if ($parentUnits >= 1) {
                            $fail('Only one unit is allowed per level in the hierarchy.');
                        }
                    }
                }
            ],

            'unit' => [
                // Conditionally apply validation rules
                function ($attribute, $value, $fail) {
                    if (is_null($this->input('parent_purchase_unit_id'))) {
                        // If parent_purchase_unit_id is nullable, make unit nullable
                        if (!is_null($value) && !is_int($value)) {
                            $fail('The unit field must be an integer if specified.');
                        }
                    } else {
                        // If parent_purchase_unit_id is not nullable, apply required and integer rules
                        if (is_null($value)) {
                            $fail('The unit field is required when parent_purchase_unit_id is not null.');
                        }
                    }
                },
                'min:1,integer' // Ensure the value is greater than or equal to 0 if provided
            ]
        ];
    }
}
