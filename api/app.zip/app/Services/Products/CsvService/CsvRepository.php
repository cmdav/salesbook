<?php

namespace App\Services\Products\CsvService;


use Illuminate\Support\Facades\DB;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Log;

class CsvRepository 
{
    public function index()
    {
		return 'index';
        
    }
    
   
}
